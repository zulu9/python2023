###########################################
#          Beispiel in Python             #
###########################################
"""
Andere Art den Titel darzustellen
"""

# todo: lies das hier
# Kommentar
'''Ebenfalls ein Kommentar'''

x = 3 - 6
print(3 + 9)
print(x)

test = 'Well, hello there!'
print(test)

print(test, x)

bsp2 = "Strings können auch so dargestellt werden."
print(bsp2)

print('Oder Sie können direkt in print() stehen.')

