# Viel Spaß bei der Fehlersuche! :)

pirnt("I work!")

x = 3-4

x.print()



